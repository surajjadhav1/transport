import Pepperoni from "../assets/service1.png";
import Margherita from "../assets/service2.png";
import PedroTechSpecial from "../assets/service3.png";

export const MenuList = [
 
  {
    name: "Pick Your Provider & Price",
    image: Margherita,
    // price: 11.99,
  },
  {
    name: "Secure Payment",
    image: Pepperoni,
    // price: 15.99,
  },
  {
    name: "Pickup at your Doorstep",
    image: PedroTechSpecial,
    // price: 256.53,
  },
  
  
];
