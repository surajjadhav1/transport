import React, { Component } from 'react'
import NavBar from './NavBar'

export default class Settings extends Component {
  render() {
    return (
      <div>
        <NavBar/>
      </div>
    )
  }
}
