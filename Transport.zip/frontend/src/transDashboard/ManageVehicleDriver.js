import React from 'react'
import NavBar from './NavBar'

export default function ManageVehicleDriver() {
  return (
    <div>
      <NavBar/>
    </div>
  )
}
