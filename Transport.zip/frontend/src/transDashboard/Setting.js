import React from 'react'
import NavBar from './NavBar'

export default function Setting() {
  return (
    <div>
      <NavBar/>
    </div>
  )
}
