import React from 'react'
import NavBar from './NavBar'
import "../styles/Home.css";
export default function Settings() {
  return (
    <div>
      <NavBar/>
      <div className="home" >
   
   <div className="headerContainer">
     <h1 style={{color:"black"}}>Settings</h1>
     <br></br>
    
     
   </div>
   

   </div>
      
     
    </div>
  )
}
