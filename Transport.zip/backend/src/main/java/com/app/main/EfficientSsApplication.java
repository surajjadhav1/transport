package com.app.main;




import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class EfficientSsApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(EfficientSsApplication.class, args);
		System.out.println("Hi");
			
	}
}
